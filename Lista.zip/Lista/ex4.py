import mysql.connector

banco = mysql.connector.connect(
    host="localhost",
    user="root",
    password="123456",
    database="unip_cc_22"
)

cursor = banco.cursor()

ras = "DELETE from matricula where RA = 12364 "
result =cursor.execute(ras)
result =cursor.fetchall()

ras = "DELETE from matricula where RA = 32146 "
result =cursor.execute(ras)
result =cursor.fetchall()



banco.commit()
cursor.close()
banco.close()
