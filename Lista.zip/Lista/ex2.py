import mysql.connector

banco = mysql.connector.connect(
    host="localhost",
    user="root",
    password="123456",
    database="unip_cc_22"
)

cursor = banco.cursor()



freq = "SELECT freq, nota FROM matricula"

result = cursor.execute(freq)
result = cursor.fetchall()

for i in range(5):
    if result[i][0] > 75 and result[i][1] >= 5:
        print("Aprovado")
    else:
        print("Reprovado")
