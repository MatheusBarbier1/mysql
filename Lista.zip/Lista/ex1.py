import mysql.connector


banco = mysql.connector.connect(
    host="localhost",
    user="root",
    password="123456",
    database="unip_cc_22"
)

cursor = banco.cursor()

aluno1 = "INSERT INTO matricula (RA, nome, nota, freq) VALUES (12364, 'matheus', 7.8, 80)"
aluno2 = "INSERT INTO matricula (RA, nome, nota, freq) VALUES (32146, 'lucas', 8.7, 90)"
aluno3 = "INSERT INTO matricula (RA, nome, nota, freq) VALUES (78965, 'joao', 5.2, 50)"
aluno4 = "INSERT INTO matricula (RA, nome, nota, freq) VALUES (66789, 'gabriel', 2.8, 10)"
aluno5 = "INSERT INTO matricula (RA, nome, nota, freq) VALUES (65911, 'decio', 10, 100)"

cursor.execute(aluno1)
cursor.execute(aluno2)
cursor.execute(aluno3)
cursor.execute(aluno4)
cursor.execute(aluno5)

banco.commit() 
cursor.close()
banco.close()