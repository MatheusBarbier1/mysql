import mysql.connector

banco = mysql.connector.connect(
    host="localhost",
    user="root",
    password="123456",
    database="unip_cc_22"
)

cursor = banco.cursor()

nota1 = "UPDATE matricula SET nota = 10 WHERE RA = 66789"
freq1 = "UPDATE matricula SET freq = 100 WHERE RA = 66789"

result = cursor.execute(nota1)
result = cursor.fetchall()

result = cursor.execute(freq1)
result = cursor.fetchall()

nota2 = "UPDATE matricula SET nota = 10 WHERE RA = 78965"
freq2 = "UPDATE matricula SET freq = 100 WHERE RA = 78965"

result = cursor.execute(nota2)
result = cursor.fetchall()

result = cursor.execute(freq2)
result = cursor.fetchall()


banco.commit()
cursor.close()
banco.close()